export * from './eventteaser.component';
