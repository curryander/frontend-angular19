export * from './teaser.component';
