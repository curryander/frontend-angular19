export * from './tile.component';
