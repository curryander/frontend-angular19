export * from './pictogram.component';
