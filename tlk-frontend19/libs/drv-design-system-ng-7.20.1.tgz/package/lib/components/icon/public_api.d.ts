export * from './icon.component';
