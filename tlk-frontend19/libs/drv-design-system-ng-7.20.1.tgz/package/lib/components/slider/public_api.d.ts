export * from './slider.component';
