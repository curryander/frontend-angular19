export * from './details.component';
