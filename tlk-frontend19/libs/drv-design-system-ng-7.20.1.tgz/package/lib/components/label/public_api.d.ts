export * from './label.component';
