export * from './richtext.component';
