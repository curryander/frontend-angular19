export * from './nfc.component';
